import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { ArrowLeft, AlertCircle } from "lucide-react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Alert, AlertDescription } from "@/components/ui/alert";

const Auth = () => {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { user, loading: authLoading } = useAuth();

  useEffect(() => {
    // Check for OAuth errors in URL parameters immediately
    const error = searchParams.get('error');
    const errorDescription = searchParams.get('error_description');
    if (error) {
      let errorMessage = 'Authentication failed. Please try again.';
      if (error === 'access_denied') {
        errorMessage = 'Access was denied. Please approve the Discord authorization to continue.';
      } else if (error === 'unauthorized_client') {
        errorMessage = 'Discord authorization failed. Please try again.';
      }
      toast({
        title: "Authentication Error",
        description: errorMessage,
        variant: "destructive",
      });
      window.history.replaceState({}, document.title, '/auth');
      return;
    }
    if (!authLoading && user && !searchParams.has('code') && !searchParams.has('access_token')) {
      navigate('/dashboard', { replace: true });
    }
  }, [navigate, searchParams, toast, user, authLoading]);

  const handleDiscordLogin = async () => {
    try {
      setLoading(true);
      try {
        await supabase.auth.signOut({ scope: 'global' });
      } catch {}
      const redirectUrl = `${window.location.origin}/auth`;
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'discord',
        options: {
          redirectTo: redirectUrl,
          scopes: 'identify guilds'
        }
      });
      if (error) {
        throw error;
      }
      setTimeout(() => {
        if (loading) {
          setLoading(false);
          toast({
            title: "Login Timeout",
            description: "Discord login is taking longer than expected. Please try again.",
            variant: "destructive",
          });
        }
      }, 3000);
    } catch (error: any) {
      let errorMessage = 'Failed to connect to Discord. Please try again.';
      if (error.message?.includes('network') || error.message?.includes('fetch')) {
        errorMessage = 'Network connection issue. Please check your internet and try again.';
      } else if (error.message?.includes('unauthorized')) {
        errorMessage = 'Discord authorization configuration issue. Please contact support.';
      } else if (error.message?.includes('Invalid login credentials')) {
        errorMessage = 'Discord authentication failed. Please try again.';
      }
      toast({
        title: "Login Failed",
        description: errorMessage,
        variant: "destructive",
      });
      setLoading(false);
    }
  };

  const hasError = searchParams.get('error');

  if (authLoading) {
    return (
      <div className="min-h-screen bg-pure-black flex items-center justify-center p-4">
        <Card className="card-dark shadow-2xl backdrop-blur-sm">
          <CardContent className="p-8">
            <div className="text-center space-y-4">
              <div className="w-8 h-8 border-4 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
              <h3 className="text-lg font-semibold text-white">Verifying authentication...</h3>
              <p className="text-gray-400">Please wait while we check your login status.</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-pure-black flex flex-col items-center justify-center p-4">
      {/* Back to home link */}
      <div className="mb-8">
        <Link to="/" className="flex items-center space-x-2 text-gray-400 hover:text-white transition-colors text-base">
          <ArrowLeft className="w-4 h-4" />
          <span>Back to home</span>
        </Link>
      </div>
      <div className="w-full max-w-md">
        <Card className="card-dark shadow-2xl backdrop-blur-sm">
          <CardHeader className="text-center space-y-2 pb-4">
            <div className="flex flex-col items-center">
              <span className="text-base text-gray-300 mb-1">Welcome to</span>
              <span className="logo-text text-3xl md:text-4xl">BuildForMe</span>
            </div>
            <CardDescription className="text-muted-foreground mt-2">
              Sign in with Discord to access AI server building
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {hasError && (
              <Alert variant="destructive" className="border-red-800/50 bg-red-900/20">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription className="text-red-300">
                  Discord authentication failed. This could be due to canceling the authorization or a network issue. Please try again.
                </AlertDescription>
              </Alert>
            )}
            <Button 
              onClick={handleDiscordLogin}
              disabled={loading}
              className="btn btn-gradient w-full text-base font-semibold rounded-lg py-3 flex items-center justify-center shadow-lg hover:shadow-xl transition-all"
              size="lg"
            >
              <svg className="mr-2 w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515a.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0a12.64 12.64 0 0 0-.617-1.25a.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057a19.9 19.9 0 0 0 5.993 3.03a.078.078 0 0 0 .084-.028a14.09 14.09 0 0 0 1.226-1.994a.076.076 0 0 0-.041-.106a13.107 13.107 0 0 1-1.872-.892a.077.077 0 0 1-.008-.128a10.2 10.2 0 0 0 .372-.292a.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127a12.299 12.299 0 0 1-1.873.892a.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028a19.839 19.839 0 0 0 6.002-3.03a.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03z"/>
              </svg>
              {loading ? "Connecting to Discord..." : "Continue with Discord"}
            </Button>
            <div className="text-center text-sm text-gray-400 mt-2">
              By continuing, you agree to our <Link to="/terms" className="underline hover:text-white">terms of service</Link> and <Link to="/privacy" className="underline hover:text-white">privacy policy</Link>.
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Auth;