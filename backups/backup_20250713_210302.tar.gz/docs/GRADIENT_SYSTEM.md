# BuildForMe Gradient System

This document describes the new animated gradient system implemented in BuildForMe.

## Overview

The gradient system provides beautiful, animated backgrounds and accents using the following color schemes:

### Primary Gradients

1. **Dimigo Gradient** (`#00c3ff` to `#ffff1c`)
   - Used for: Logo, primary buttons, accent cards
   - Class: `bg-dimigo-gradient`, `btn-gradient-dimigo`, `card-accent-dimigo`

2. **Purplin Gradient** (`#6a3093` to `#a044ff`)
   - Used for: Premium features, secondary buttons, popular items
   - Class: `bg-purplin-gradient`, `btn-gradient-purplin`, `card-accent-purplin`

3. **Flame Gradient** (`#ff0000` to `#fdcf58`)
   - Used for: Call-to-action buttons, warning states, highlights
   - Class: `bg-flame-gradient`, `btn-gradient-flame`, `card-accent-flame`

### Additional Gradients

- **Ocean Gradient** (`#667eea` to `#764ba2`)
- **Sunset Gradient** (`#f093fb` to `#f5576c`)
- **Forest Gradient** (`#4facfe` to `#00f2fe`)

## Usage

### Background Classes

```css
.bg-animated-gradient          /* Fast animation (8s) */
.bg-animated-gradient-slow     /* Slow animation (25s) */
.bg-animated-gradient-fast     /* Medium animation (15s) */
```

### Button Classes

```css
.btn-gradient-dimigo
.btn-gradient-purplin
.btn-gradient-flame
```

### Card Accent Classes

```css
.card-accent-dimigo
.card-accent-purplin
.card-accent-flame
```

### Text Gradient Classes

```css
.text-gradient-animated        /* Animated gradient text */
.text-gradient-dimigo
.text-gradient-purplin
.text-gradient-flame
```

## Implementation Details

### Floating Orbs

The main background uses three floating gradient orbs that move independently:
- `.gradient-orb-1` - Dimigo gradient, top-left
- `.gradient-orb-2` - Purplin gradient, bottom-right  
- `.gradient-orb-3` - Flame gradient, bottom-left

### Animations

- `gradientShift` - Shifts gradient positions for animated backgrounds
- `float` - Floating motion for gradient orbs
- `pulseGlow` - Pulsing glow effects
- `shimmer` - Loading state shimmer effects

## Best Practices

1. **Use sparingly** - Don't overuse gradients on every element
2. **Maintain contrast** - Ensure text remains readable over gradients
3. **Consistent theming** - Use the same gradient family for related elements
4. **Performance** - Animated gradients are GPU-intensive, use with care

## Customization

To add new gradients, add them to the CSS variables in `src/index.css`:

```css
--gradient-your-name: linear-gradient(135deg, #color1 0%, #color2 100%);
```

Then create corresponding utility classes:

```css
.bg-your-name-gradient {
  background: var(--gradient-your-name);
}
``` 