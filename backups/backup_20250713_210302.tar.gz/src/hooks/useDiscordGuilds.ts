import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

export interface Guild {
  id: string;
  name: string;
  icon: string | null;
  icon_url: string | null;
  owner: boolean;
  permissions: string;
  features: string[];
  member_count: number;
  subscription_status: string;
  bot_installed?: boolean;
}

export const useDiscordGuilds = () => {
  const [guilds, setGuilds] = useState<Guild[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user, session } = useAuth();
  const { toast } = useToast();

  const fetchGuilds = async () => {
    if (!user || !session) {
      setGuilds([]);
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError(null);

      const { data, error: fetchError } = await supabase.functions.invoke('discord-guilds', {
        headers: {
          Authorization: `Bearer ${session.access_token}`,
        },
      });

      if (fetchError) {
        throw new Error(fetchError.message || 'Failed to fetch Discord guilds');
      }

      setGuilds(data || []);
    } catch (err: any) {
      console.error('Error fetching Discord guilds:', err);
      setError(err.message || 'Failed to load Discord servers');
      
      // Show toast notification for errors
      toast({
        title: "Error Loading Servers",
        description: err.message || "Failed to load Discord servers. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  // Fetch guilds when user/session changes
  useEffect(() => {
    fetchGuilds();
  }, [user, session]);

  const refetch = () => {
    fetchGuilds();
  };

  return {
    guilds,
    loading,
    error,
    refetch,
  };
}; 