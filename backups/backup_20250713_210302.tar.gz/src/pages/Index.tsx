import React from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { Bot, Zap, Settings, Crown, ArrowRight, Sparkles, Server, Shield, Wand2 } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";

const Index = () => {
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-pure-black relative overflow-hidden">
      {/* Subtle background gradients */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-20 left-10 w-72 h-72 bg-gradient-to-r from-purple-900/20 to-transparent rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-gradient-to-l from-red-900/20 to-transparent rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-gradient-to-r from-orange-900/20 to-transparent rounded-full blur-3xl"></div>
      </div>

      <div className="container mx-auto max-w-6xl py-16 px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <Badge className="bg-gray-800 text-gray-300 px-3 py-1 text-sm font-medium mb-6 border border-gray-700">
            <Sparkles className="mr-2 h-3 w-3" />
            AI-Powered Discord Bot
          </Badge>
          
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-white mb-6 tracking-tight leading-tight">
            Build Discord servers
            <span className="gradient-text-animated">
              {" "}in seconds
            </span>
          </h1>
          
          <div className="max-w-3xl mx-auto">
            <p className="text-lg sm:text-xl md:text-2xl text-gray-400 mb-8">
              Professional AI Discord Server Builder that creates, manages, and optimizes 
              your Discord server with intelligent automation.
            </p>
            
            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-3 justify-center items-center mb-8">
              {user ? (
                <Button 
                  asChild 
                  className="btn btn-gradient px-6 py-3 text-base font-medium shadow-lg hover:shadow-xl transition-all"
                >
                  <Link to="/dashboard">
                    <Settings className="mr-2 h-4 w-4" />
                    Open Dashboard
                  </Link>
                </Button>
              ) : (
                <Button 
                  asChild 
                  className="btn btn-gradient px-6 py-3 text-base font-medium shadow-lg hover:shadow-xl transition-all"
                >
                  <Link to="/auth">
                    <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M20.317 4.3698a19.7913 19.7913 0 00-4.8851-1.5152.0741.0741 0 00-.0785.0371c-.211.3753-.4447.8648-.6083 1.2495-1.8447-.2762-3.68-.2762-5.4868 0-.1636-.3933-.4058-.8742-.6177-1.2495a.077.077 0 00-.0785-.037 19.7363 19.7363 0 00-4.8852 1.515.0699.0699 0 00-.0321.0277C.5334 9.0458-.319 13.5799.0992 18.0578a.0824.0824 0 00.0312.0561c2.0528 1.5076 4.0413 2.4228 5.9929 3.0294a.0777.0777 0 00.0842-.0276c.4616-.6304.8731-1.2952 1.226-1.9942a.076.076 0 00-.0416-.1057c-.6528-.2476-1.2743-.5495-1.8722-.8923a.077.077 0 01-.0076-.1277c.1258-.0943.2517-.1923.3718-.2914a.0743.0743 0 01.0776-.0105c3.9278 1.7933 8.18 1.7933 12.0614 0a.0739.0739 0 01.0785.0095c.1202.099.246.1981.3728.2924a.077.077 0 01-.0066.1276 12.2986 12.2986 0 01-1.873.8914.0766.0766 0 00-.0407.1067c.3604.698.7719 1.3628 1.225 1.9932a.076.076 0 00.0842.0286c1.961-.6067 3.9495-1.5219 6.0023-3.0294a.077.077 0 00.0313-.0552c.5004-5.177-.8382-9.6739-3.5485-13.6604a.061.061 0 00-.0312-.0286zM8.02 15.3312c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9555-2.4189 2.157-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419-.0189 1.3332-.9555 2.4189-2.1569 2.4189zm7.9748 0c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9554-2.4189 2.1569-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.946 2.4189-2.1568 2.4189Z"/>
                    </svg>
                    Sign in with Discord
                  </Link>
                </Button>
              )}
              
              <Button 
                asChild
                variant="outline" 
                className="btn btn-primary px-6 py-3 text-base font-medium transition-all"
              >
                <Link to="/pricing">
                  <Crown className="mr-2 h-4 w-4" />
                  View Pricing
                </Link>
              </Button>
            </div>

            {/* Features preview */}
            <div className="text-gray-400 text-sm">
              Free tier available • Discord-only login • Premium $20/month
            </div>
          </div>
        </div>
      </div>

      {/* Bot Features Section */}
      <section className="relative py-12 sm:py-16 bg-gradient-to-b from-transparent via-gray-900/10 to-transparent">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-heading text-white mb-6">
              What BuildForMe Can Do
            </h2>
            <p className="text-subheading max-w-3xl mx-auto">
              Our AI bot handles everything from server setup to optimization, 
              so you can focus on building your community.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {botFeatures.map((feature, index) => (
              <Card key={index} className="bg-gray-900 border-gray-800 backdrop-blur-sm">
                <CardHeader>
                  <div className="flex items-center justify-between mb-3">
                    <div className="p-2 rounded-lg bg-gray-700">
                      <feature.icon className="h-5 w-5 text-white" />
                    </div>
                    {feature.premium && (
                      <Badge className="badge badge-gradient text-white text-xs">
                        Premium
                      </Badge>
                    )}
                  </div>
                  <CardTitle className="text-lg text-white">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-gray-400 text-sm leading-relaxed">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative py-12 sm:py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-heading text-white mb-6">
            Ready to transform your Discord server?
          </h2>
          <p className="text-subheading max-w-3xl mx-auto mb-8">
            Join thousands of server owners using BuildForMe to create 
            professional Discord communities in minutes, not hours.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-3 justify-center items-center">
            {user ? (
              <Button 
                asChild 
                className="btn btn-gradient px-6 py-3 text-base font-medium shadow-lg hover:shadow-xl transition-all w-auto"
              >
                <Link to="/dashboard">
                  Go to Dashboard
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            ) : (
              <Button 
                asChild 
                className="btn btn-gradient px-6 py-3 text-base font-medium shadow-lg hover:shadow-xl transition-all w-auto"
              >
                <Link to="/auth">
                  Get Started Free
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};

// Bot features based on professional_builder_bot.py
const botFeatures = [
  {
    icon: Wand2,
    title: "AI-Powered Server Setup",
    description: "Complete server setup in seconds with AI that creates channels, categories, roles, and permissions based on your theme.",
    color: "bg-gray-700",
    premium: true
  },
  {
    icon: Settings,
    title: "Smart Channel Management", 
    description: "Add, remove, and organize channels with intelligent naming and structure. Protected channels ensure important areas stay safe.",
    color: "bg-gray-700",
    premium: false
  },
  {
    icon: Shield,
    title: "Permission Optimization",
    description: "AI analyzes and fixes permission issues automatically. Ensures proper role hierarchy and prevents common security mistakes.",
    color: "bg-gray-700",
    premium: true
  },
  {
    icon: Server,
    title: "Server Cleanup & Analysis",
    description: "Interactive cleanup tools identify unused channels, optimize structure, and provide detailed server health reports.",
    color: "bg-gray-700", 
    premium: true
  },
  {
    icon: Zap,
    title: "Theme Application",
    description: "Instantly transform your server with professionally designed themes. Renames channels, roles, and restructures as needed.",
    color: "bg-gray-700",
    premium: true
  },
  {
    icon: Bot,
    title: "Admin Command Hub",
    description: "Protected admin channels and comprehensive permission checking. Works seamlessly with your existing moderation tools.",
    color: "bg-gray-700",
    premium: false
  }
];

export default Index;
