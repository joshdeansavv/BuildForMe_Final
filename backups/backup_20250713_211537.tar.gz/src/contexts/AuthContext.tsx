import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';

interface SubscriptionData {
  subscribed: boolean;
  subscription_tier: string;
  subscription_end?: string;
}

interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  subscription: SubscriptionData | null;
  refreshSubscription: () => Promise<void>;
  signOut: () => Promise<void>;
  clearAuthState: () => void;
  createProfileManually: () => Promise<boolean>;
  checkProfileExists: () => Promise<boolean>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [subscription, setSubscription] = useState<SubscriptionData | null>(null);
  const [loading, setLoading] = useState(true);

  const checkSubscription = async (userSession: Session | null) => {
    if (!userSession) {
      setSubscription(null);
      return;
    }

    try {
      const { data, error } = await supabase.functions.invoke('check-subscription', {
        headers: {
          Authorization: `Bearer ${userSession.access_token}`,
        },
      });

      if (error) {
        console.error('Error checking subscription:', error.message || error);
        setSubscription({ subscribed: false, subscription_tier: 'free' });
      } else {
        setSubscription(data || { subscribed: false, subscription_tier: 'free' });
      }
    } catch (error: any) {
      console.error('Error checking subscription:', error.message || error);
      setSubscription({ subscribed: false, subscription_tier: 'free' });
    }
  };

  const refreshSubscription = async () => {
    await checkSubscription(session);
  };

  useEffect(() => {
    // Set up auth state listener - synchronous only to prevent deadlock
    const { data: { subscription: authSubscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        console.log('Auth state change:', event, session?.user?.id || 'no user');
        setSession(session);
        setUser(session?.user ?? null);
        
        if (event === 'SIGNED_IN' && session) {
          setTimeout(() => {
            checkSubscription(session);
          }, 0);
        } else if (event === 'SIGNED_OUT') {
          setSubscription(null);
        }
        
        setLoading(false);
      }
    );

    // Check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      console.log('Initial session check:', session?.user?.id || 'no user');
      setSession(session);
      setUser(session?.user ?? null);
      if (session) {
        checkSubscription(session);
      }
      setLoading(false);
    });

    return () => authSubscription.unsubscribe();
  }, []);

  // Separate effect to handle profile creation/update
  useEffect(() => {
    const createOrUpdateProfile = async (user: User) => {
      console.log('Creating/updating profile for user:', user.id);
      console.log('User metadata:', user.user_metadata);
      
      const discordData = user.user_metadata;
      
      // Extract Discord data with better fallbacks
      const profileData = {
        id: user.id,
        discord_id: discordData?.provider_id || discordData?.sub || discordData?.id,
        username: discordData?.global_name || discordData?.username || discordData?.full_name || discordData?.preferred_username || discordData?.name || user.email?.split('@')[0] || 'Discord User',
        avatar_url: discordData?.avatar_url || discordData?.picture,
        email: user.email,
      };

      console.log('Profile data to upsert:', profileData);

      try {
        const { data, error } = await supabase
          .from('profiles')
          .upsert(profileData, { 
            onConflict: 'id',
            ignoreDuplicates: false 
          })
          .select();

        if (error) {
          console.error('Profile upsert error:', error);
          console.error('Error details:', error.message, error.details, error.hint);
        } else {
          console.log('Profile upserted successfully:', data);
        }
      } catch (error) {
        console.error('Error in createOrUpdateProfile:', error);
      }
    };

    // Only create/update profile when user is available and not loading
    if (user && !loading) {
      createOrUpdateProfile(user);
    }
  }, [user, loading]);

  const clearAuthState = () => {
    // Clear all auth-related data from localStorage and sessionStorage
    Object.keys(localStorage).forEach((key) => {
      if (key.startsWith('supabase.auth.') || key.includes('sb-')) {
        localStorage.removeItem(key);
      }
    });
    
    Object.keys(sessionStorage || {}).forEach((key) => {
      if (key.startsWith('supabase.auth.') || key.includes('sb-')) {
        sessionStorage.removeItem(key);
      }
    });
    
    setUser(null);
    setSession(null);
    setSubscription(null);
  };

  const checkProfileExists = async (): Promise<boolean> => {
    if (!user) return false;
    
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('id')
        .eq('id', user.id)
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('Error checking profile:', error);
        return false;
      }

      return !!data;
    } catch (error) {
      console.error('Error in checkProfileExists:', error);
      return false;
    }
  };

  const createProfileManually = async (): Promise<boolean> => {
    if (!user) return false;

    console.log('Manually creating profile for user:', user.id);
    const discordData = user.user_metadata;
    
    const profileData = {
      id: user.id,
      discord_id: discordData?.provider_id || discordData?.sub || discordData?.id,
      username: discordData?.global_name || discordData?.username || discordData?.full_name || discordData?.preferred_username || discordData?.name || user.email?.split('@')[0] || 'Discord User',
      avatar_url: discordData?.avatar_url || discordData?.picture,
      email: user.email,
    };

    console.log('Manual profile data:', profileData);

    try {
      const { data, error } = await supabase
        .from('profiles')
        .insert(profileData)
        .select();

      if (error) {
        console.error('Manual profile creation error:', error);
        return false;
      }

      console.log('Profile created manually:', data);
      return true;
    } catch (error) {
      console.error('Error in createProfileManually:', error);
      return false;
    }
  };

  const signOut = async () => {
    try {
      // Clear auth state first
      clearAuthState();
      
      // Attempt global sign out
      await supabase.auth.signOut({ scope: 'global' });
      
      // Force page reload for clean state
      window.location.href = '/';
    } catch (error) {
      console.error('Error signing out:', error);
      // Force reload even if signOut fails
      window.location.href = '/';
    }
  };

  const value = {
    user,
    session,
    loading,
    subscription,
    refreshSubscription,
    signOut,
    clearAuthState,
    createProfileManually,
    checkProfileExists,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};