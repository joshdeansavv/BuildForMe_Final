import { serve } from "https://deno.land/std@0.190.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.0'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

function logStep(message: string, data?: any) {
  const dataStr = data ? ` - ${JSON.stringify(data)}` : '';
  console.log(`[DISCORD-GUILDS] ${message}${dataStr}`);
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    logStep("Function started");
    
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      { auth: { persistSession: false } }
    )

    // Get the user from the Authorization header
    const authHeader = req.headers.get('Authorization')
    if (!authHeader) {
      throw new Error('No authorization header')
    }

    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(
      authHeader.replace('Bearer ', '')
    )

    if (authError || !user) {
      logStep("Authentication failed", { error: authError?.message });
      throw new Error('Invalid user token')
    }

    logStep("User authenticated", { userId: user.id });

    // Get Discord access token from user metadata
    const discordAccessToken = user.user_metadata?.provider_token
    if (!discordAccessToken) {
      logStep("No Discord token found");
      // Return empty array if no Discord token
      return new Response(
        JSON.stringify({ guilds: [] }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200,
        }
      )
    }

    logStep("Discord token found, fetching guilds");

    // Fetch user's Discord guilds
    const discordResponse = await fetch('https://discord.com/api/users/@me/guilds', {
      headers: {
        'Authorization': `Bearer ${discordAccessToken}`,
        'Content-Type': 'application/json',
      },
    })

    if (!discordResponse.ok) {
      if (discordResponse.status === 401) {
        logStep("Discord token expired");
        // Return empty array if token is expired
        return new Response(
          JSON.stringify({ guilds: [], error: 'Discord token expired' }),
          { 
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 200,
          }
        )
      }
      throw new Error(`Discord API error: ${discordResponse.status} ${discordResponse.statusText}`)
    }

    const guilds = await discordResponse.json()
    logStep("Guilds fetched successfully", { count: guilds.length });

    // Filter guilds where user has admin permissions (permission & 0x8)
    const adminGuilds = guilds.filter((guild: any) => {
      const hasAdminPermission = (guild.permissions & 0x8) === 0x8
      const isOwner = guild.owner === true
      return hasAdminPermission || isOwner
    })

    logStep("Admin guilds filtered", { adminCount: adminGuilds.length });

    // Transform guild data for frontend
    const transformedGuilds = adminGuilds.map((guild: any) => ({
      id: guild.id,
      name: guild.name,
      icon: guild.icon,
      owner: guild.owner,
      permissions: guild.permissions,
      features: guild.features || [],
      icon_url: guild.icon 
        ? `https://cdn.discordapp.com/icons/${guild.id}/${guild.icon}.png?size=128`
        : null
    }))

    // Check which guilds have active subscriptions
    const guildIds = transformedGuilds.map(g => g.id)
    const { data: servers } = await supabaseClient
      .from('servers')
      .select('discord_guild_id, subscription_status')
      .in('discord_guild_id', guildIds)

    // Add subscription status to guilds
    const guildsWithStatus = transformedGuilds.map(guild => {
      const server = servers?.find(s => s.discord_guild_id === guild.id)
      return {
        ...guild,
        subscription_status: server?.subscription_status || 'none'
      }
    })

    logStep("Guilds processed with subscription status", { finalCount: guildsWithStatus.length });

    return new Response(
      JSON.stringify({ guilds: guildsWithStatus }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    )

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    logStep("❌ Error in discord-guilds", { message: errorMessage });
    return new Response(
      JSON.stringify({ 
        error: errorMessage,
        guilds: []
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }, 
        status: 500 
      }
    )
  }
}) 