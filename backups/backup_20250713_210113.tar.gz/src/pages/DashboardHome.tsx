import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { DashboardBreadcrumbs } from '@/components/ui/breadcrumb';
import { 
  Server, 
  Crown, 
  CreditCard,
  Plus,
  Bot,
  Settings,
  ExternalLink,
  Loader2,
  Users,
  CheckCircle,
  AlertTriangle,
  Sparkles,
  Calendar,
  ArrowRight
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useDiscordGuilds } from '@/hooks/useDiscordGuilds';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

export default function DashboardHome() {
  const { user, subscription, session } = useAuth();
  const { guilds, loading: guildsLoading, refetch: refetchGuilds } = useDiscordGuilds();
  const { toast } = useToast();
  const [billingLoading, setBillingLoading] = useState(false);

  const isActive = subscription?.subscription_status === 'active';
  const activeServers = guilds.filter(guild => guild.subscription_status === 'active');

  const handleManageBilling = async () => {
    if (!user || !session) {
      toast({
        title: "Authentication Required",
        description: "Please log in to manage your billing.",
      });
      return;
    }

    setBillingLoading(true);

    try {
      const response = await supabase.functions.invoke('stripe-customer-portal', {
        headers: {
          Authorization: `Bearer ${session.access_token}`,
        },
      });

      if (response.error) {
        throw new Error(response.error.message || 'Failed to create billing portal session');
      }

      const { url } = response.data;
      window.location.href = url;

    } catch (error: any) {
      console.error('Error creating billing portal session:', error.message || error);
      toast({
        title: "Error",
        description: error.message || "Failed to access billing portal. Please try again.",
        variant: "destructive",
      });
    } finally {
      setBillingLoading(false);
    }
  };

  const handleInviteBot = (guildId: string) => {
    const clientId = '1391912825534025879';
    const permissions = '8';
    const scope = 'bot%20applications.commands';
    const inviteUrl = `https://discord.com/api/oauth2/authorize?client_id=${clientId}&permissions=${permissions}&scope=${scope}&guild_id=${guildId}`;
    window.open(inviteUrl, '_blank');
  };

  return (
    <div className="section space-y-lg">
      <DashboardBreadcrumbs currentPage="Dashboard" />

      {/* Welcome Header */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-white mb-2">
          Welcome back, {user?.user_metadata?.global_name || user?.user_metadata?.username || user?.email?.split('@')[0] || 'User'}!
        </h1>
        <p className="text-lg text-muted">Manage your Discord servers and subscription</p>
      </div>

      {/* 3 Main Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* 1. Discord Servers Card */}
        <Card className="lg:col-span-2 card-dark">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-white flex items-center gap-2">
                <Server className="h-5 w-5 text-primary" />
                Your Discord Servers
              </CardTitle>
              <CardDescription>
                Discord servers where you have admin permissions
              </CardDescription>
            </div>
            <Button 
              onClick={refetchGuilds}
              variant="outline"
              size="sm"
              className="border-border/50"
            >
              <Settings className="h-4 w-4" />
            </Button>
          </CardHeader>
          <CardContent>
            {guildsLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin text-primary" />
                <span className="ml-2 text-muted">Loading servers...</span>
              </div>
            ) : guilds.length === 0 ? (
              <div className="text-center py-8">
                <Server className="h-12 w-12 mx-auto mb-3 text-muted/50" />
                <p className="text-white font-medium mb-1">No servers found</p>
                <p className="text-sm text-muted mb-4">Connect your Discord account to see your servers</p>
                <Button asChild>
                  <Link to="/auth">Connect Discord</Link>
                </Button>
              </div>
            ) : (
              <div className="space-y-3 max-h-80 overflow-y-auto">
                {guilds.slice(0, 6).map((guild) => (
                  <div key={guild.id} className="flex items-center justify-between p-3 bg-muted/10 rounded-lg border border-border/30">
                    <div className="flex items-center space-x-3">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={guild.icon_url || undefined} />
                        <AvatarFallback className="bg-primary/20">
                          <Server className="h-5 w-5" />
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="text-white font-medium">{guild.name}</p>
                        <div className="flex items-center gap-3 text-sm text-muted">
                          <span className="flex items-center gap-1">
                            <Users className="h-3 w-3" />
                            {guild.member_count?.toLocaleString() || 0}
                          </span>
                          {guild.owner && <Crown className="h-3 w-3 text-yellow-400" />}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge 
                        variant={guild.subscription_status === 'active' ? 'default' : 'secondary'}
                        className={guild.subscription_status === 'active' ? 'bg-green-600' : ''}
                      >
                        {guild.subscription_status === 'active' ? 'Premium' : 'Free'}
                      </Badge>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleInviteBot(guild.id)}
                        className="text-primary hover:text-primary/80"
                      >
                        <Bot className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
                {guilds.length > 6 && (
                  <Button asChild variant="outline" className="w-full mt-4">
                    <Link to="/servers">
                      View All Servers ({guilds.length})
                    </Link>
                  </Button>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* 2. Subscription Status Card */}
        <Card className="card-dark">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Crown className="h-5 w-5 text-primary" />
              Subscription
            </CardTitle>
            <CardDescription>
              Current plan and status
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center py-4">
              <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 ${
                isActive ? 'bg-green-500/20' : 'bg-gray-500/20'
              }`}>
                {isActive ? (
                  <CheckCircle className="h-8 w-8 text-green-400" />
                ) : (
                  <AlertTriangle className="h-8 w-8 text-yellow-400" />
                )}
              </div>
              
              <h3 className="text-xl font-bold text-white mb-2">
                {isActive ? 'Premium Active' : 'Free Plan'}
              </h3>
              
              <Badge 
                className={`mb-4 ${
                  isActive 
                    ? 'bg-green-500/20 text-green-400 border-green-500/30' 
                    : 'bg-blue-500/20 text-blue-400 border-blue-500/30'
                }`}
              >
                {subscription?.subscription_tier || 'Basic'}
              </Badge>

              {isActive ? (
                <div className="space-y-2 text-sm text-muted">
                  <p>✨ AI-powered server building</p>
                  <p>🚀 Premium features enabled</p>
                  <p>🛡️ Priority support</p>
                  {subscription?.subscription_end && (
                    <p className="flex items-center justify-center gap-1 mt-3">
                      <Calendar className="h-3 w-3" />
                      Next billing: {new Date(subscription.subscription_end).toLocaleDateString()}
                    </p>
                  )}
                </div>
              ) : (
                <div className="space-y-3">
                  <p className="text-sm text-muted mb-4">
                    Upgrade to unlock AI-powered Discord server building
                  </p>
                  <Button asChild className="w-full btn-primary">
                    <Link to="/pricing">
                      <Sparkles className="h-4 w-4 mr-2" />
                      Upgrade to Premium
                    </Link>
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 3. Billing Management Card */}
      <Card className="card-dark">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <CreditCard className="h-5 w-5 text-primary" />
            Billing & Payments
          </CardTitle>
          <CardDescription>
            Manage your subscription and payment methods
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* Billing Actions */}
            <div className="md:col-span-2 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 bg-muted/10 rounded-lg border border-border/30">
                  <h4 className="text-white font-medium mb-2">Current Plan</h4>
                  <p className="text-2xl font-bold text-white">
                    {isActive ? '$20' : '$0'}
                    <span className="text-sm text-muted font-normal">
                      {isActive ? '/month' : ''}
                    </span>
                  </p>
                  <p className="text-sm text-muted">
                    {subscription?.subscription_tier || 'Free Plan'}
                  </p>
                </div>

                <div className="p-4 bg-muted/10 rounded-lg border border-border/30">
                  <h4 className="text-white font-medium mb-2">Active Servers</h4>
                  <p className="text-2xl font-bold text-white">{activeServers.length}</p>
                  <p className="text-sm text-muted">Premium servers</p>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-3">
                {isActive ? (
                  <Button 
                    onClick={handleManageBilling}
                    disabled={billingLoading}
                    className="flex-1 btn-primary"
                  >
                    {billingLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Loading...
                      </>
                    ) : (
                      <>
                        <CreditCard className="mr-2 h-4 w-4" />
                        Manage Billing
                      </>
                    )}
                  </Button>
                ) : (
                  <Button asChild className="flex-1 btn-primary">
                    <Link to="/pricing">
                      <Crown className="mr-2 h-4 w-4" />
                      Upgrade Now
                    </Link>
                  </Button>
                )}
                
                <Button asChild variant="outline" className="flex-1 border-border/50">
                  <Link to="/pricing">
                    <ExternalLink className="mr-2 h-4 w-4" />
                    View Plans
                  </Link>
                </Button>
              </div>
            </div>

            {/* Payment Info */}
            <div className="space-y-4">
              <div className="p-4 bg-muted/10 rounded-lg border border-border/30 text-center">
                <CreditCard className="h-8 w-8 mx-auto mb-3 text-muted/50" />
                <p className="text-white font-medium mb-1">Secure Payments</p>
                <p className="text-sm text-muted">Powered by Stripe</p>
              </div>
              
              <div className="text-center">
                <Button asChild variant="outline" size="sm" className="border-border/50">
                  <a 
                    href="https://discord.gg/4NTc5Pmhhy"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <ExternalLink className="mr-2 h-3 w-3" />
                    Support
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
} 